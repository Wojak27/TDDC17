package src.TDDC17Lab1;

import aima.core.agent.impl.AbstractAgent;

public class MyVacuumAgent extends AbstractAgent {
    public MyVacuumAgent() {
    	super(new MyAgentProgram());
	}
}