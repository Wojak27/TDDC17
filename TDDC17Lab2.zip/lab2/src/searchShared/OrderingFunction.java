package searchShared;


public class OrderingFunction {

    public void addNodeToQueue(SearchNode node, NodeQueue q) {
        throw new RuntimeException("should be implemented by subclass");
    }
}
